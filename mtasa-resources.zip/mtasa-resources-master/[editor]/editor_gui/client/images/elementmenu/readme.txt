++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This copyright and license notice covers the images in this directory.
************************************************************************

TITLE:	Crystal Project Icons
AUTHOR:	Everaldo Coelho
SITE:	https://www.everaldo.com
CONTACT: everaldo@everaldo.com

Copyright (c)  2006-2007  Everaldo Coelho.
